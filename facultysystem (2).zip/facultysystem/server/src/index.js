const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const yaml = require("js-yaml");
const swaggerUi = require("swagger-ui-express");

require("dotenv").config({
  path: path.join(__dirname, "../.env"),
});

const connectDB = require("./config/database");
const errorHandler = require("./middleware/error-handler");
const { protect, authorize } = require("./middleware/auth.middleware");

// Routes
const authRoutes = require("./routes/auth.routes");
const facultyRoutes = require("./routes/faculty.Routes");
const departmentRoutes = require("./routes/department.Routes");
const nonFacultyRoutes = require("./routes/non-faculty.Routes");
const subjectRoutes = require("./routes/subject.Routes");
const scheduleRoutes = require("./routes/schedule.Routes");
const reportRoutes = require("./routes/report.Routes");

const app = express();
const PORT = process.env.PORT || 5000;

// CORS: allow the Vite frontend (CLIENT_URL) plus common local ports
const allowedOrigins = [
  process.env.CLIENT_URL,
  "http://localhost:5173",
  "http://localhost:8443",
  "http://127.0.0.1:8443",
].filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error(`CORS blocked: ${origin}`));
    },
    credentials: true,
  })
);
app.use(express.json());

// Health check (public)
app.get("/api/v1/health", (req, res) => {
  res.status(200).json({ status: "ok" });
});

// Public authentication routes
app.use("/api/v1/auth", authRoutes);

// Protected management routes.
// Set REQUIRE_AUTH=false in .env to disable login checks during development.
const guard =
  process.env.REQUIRE_AUTH === "false" ? [] : [protect, authorize("admin")];

app.use("/api/v1/faculty", ...guard, facultyRoutes);
app.use("/api/v1/departments", ...guard, departmentRoutes);
app.use("/api/v1/non-faculty", ...guard, nonFacultyRoutes);
app.use("/api/v1/subjects", ...guard, subjectRoutes);
app.use("/api/v1/schedules", ...guard, scheduleRoutes);
app.use("/api/v1/reports", ...guard, reportRoutes);

// Swagger documentation
const openApiPath = path.join(__dirname, "../openapi.yaml");

if (fs.existsSync(openApiPath)) {
  const openApiDocument = yaml.load(fs.readFileSync(openApiPath, "utf8"));
  app.use("/docs", swaggerUi.serve, swaggerUi.setup(openApiDocument));
} else {
  console.warn("openapi.yaml was not found. Swagger documentation is disabled.");
}

// Root route
app.get("/", (req, res) => {
  res.send("Faculty Module API is running!");
});

// Unknown API routes -> JSON 404
app.use("/api", (req, res) => {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
});

// Error handler (keep this after your routes)
app.use(errorHandler);

// Start server
async function startServer() {
  try {
    await connectDB();

    app.listen(PORT, () => {
      console.log(`Faculty API running at http://localhost:${PORT}`);
      console.log(`Health check: http://localhost:${PORT}/api/v1/health`);
      console.log(`Swagger UI: http://localhost:${PORT}/docs`);
      console.log(
        process.env.REQUIRE_AUTH === "false"
          ? "Auth: DISABLED (development)"
          : "Auth: enabled (admin token required)"
      );
    });
  } catch (error) {
    console.error("Could not start the API:", error.message);
    process.exit(1);
  }
}

startServer();